<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
</head>
<body>
  <h2>회원가입 성공!</h2>
  이름 : <?php echo e($name); ?> <br>
  생년월일 : <?php echo e($birthDate); ?> <br>
  이메일 : <?php echo e($email); ?> <br>
  소속 : <?php echo e($org); ?> <br>
</body>
</html><?php /**PATH D:\scpark\2023_2\workspace\laravel_study\resources\views/register.blade.php ENDPATH**/ ?>