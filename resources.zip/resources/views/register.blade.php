<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
</head>
<body>
  <h2>회원가입 성공!</h2>
  이름 : {{$name}} <br>
  생년월일 : {{$birthDate}} <br>
  이메일 : {{$email}} <br>
  소속 : {{$org}} <br>
</body>
</html>